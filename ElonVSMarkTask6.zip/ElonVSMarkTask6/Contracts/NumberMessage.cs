﻿using CardDeck;

namespace Contracts
{
    public record NumberMessage
    {
        public int Number { get; init; }
        public string? Player { get; init; }
    }
}
