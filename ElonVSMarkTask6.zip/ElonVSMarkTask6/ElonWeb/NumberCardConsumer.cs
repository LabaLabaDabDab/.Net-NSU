﻿using Contracts;
using MassTransit;

namespace ElonWeb
{
    public class NumberCardConsumer : IConsumer<NumberMessage>
    {
        public Task Consume(ConsumeContext<NumberMessage> context)
        {
            if (context.Message.Player == "Mark")
            {                
                ElonStats.Color = ElonStats.Cards[context.Message.Number].Color;
                ResourceLock.ResourceAvailable();
            }

            return Task.CompletedTask;
        }
    }
}
