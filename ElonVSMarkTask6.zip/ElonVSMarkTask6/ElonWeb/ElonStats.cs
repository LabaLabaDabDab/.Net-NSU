﻿using CardDeck;

namespace ElonWeb
{
    public class ElonStats
    {
        internal static List<Card> Cards { get; set; }
        internal static CardColor Color { get; set; }
    }
}
