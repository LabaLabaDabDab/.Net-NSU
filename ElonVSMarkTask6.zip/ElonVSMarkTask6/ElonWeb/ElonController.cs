﻿using CardDeck;
using Microsoft.AspNetCore.Mvc;

namespace ElonWeb
{
    [ApiController]
    public class ElonController : ControllerBase
    {
        [Route("game")]
        [HttpGet]
        public async Task<CardColor> GetColor()
        {
            await ResourceLock.WaitForResourceAsync();
            return await Task.FromResult(ElonStats.Color);
        }
    }
}
