﻿namespace CardDeck
{
    public interface IDeckShuffler
    {
        List<Card> ShuffleDeck(List<Card> deck);
    }
}
