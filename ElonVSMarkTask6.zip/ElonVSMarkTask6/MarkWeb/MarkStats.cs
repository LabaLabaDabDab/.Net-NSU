﻿using CardDeck;

namespace MarkWeb
{
    public class MarkStats
    {
        internal static List<Card> Cards { get; set; }
        internal static CardColor Color { get; set; }
    }
}
