﻿using Contracts;
using MarkWeb;
using MassTransit;

namespace MarkWeb
{
    public class NumberCardConsumer : IConsumer<NumberMessage>
    {
        public Task Consume(ConsumeContext<NumberMessage> context)
        {
            if (context.Message.Player == "Elon")
            {
                //Console.WriteLine($"This is the message from {context.Message.Player}. The number is {context.Message.Number}");
                MarkStats.Color = MarkStats.Cards[context.Message.Number].Color;
                ResourceLock.ResourceAvailable();
            }

            return Task.CompletedTask;
        }
    }
}
