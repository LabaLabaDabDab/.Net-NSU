﻿using CardDeck;
using Microsoft.AspNetCore.Mvc;

namespace MarkWeb
{
    [ApiController]
    public class MarkController : ControllerBase
    {
        [Route("game")]
        [HttpGet]
        public async Task<CardColor> GetColor()
        {
            await ResourceLock.WaitForResourceAsync();
            return await Task.FromResult(MarkStats.Color);
        }
    }
}
